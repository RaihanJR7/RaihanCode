package com;

import org.testng.annotations.Test;

public class SmokeTest extends BaseTest {
	
	@Test (groups = "ui")
	public void test1() {
		System.out.println("test1");
	}

}
