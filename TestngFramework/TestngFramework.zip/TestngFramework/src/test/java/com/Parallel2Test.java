package com;

public class Parallel2Test {

}
