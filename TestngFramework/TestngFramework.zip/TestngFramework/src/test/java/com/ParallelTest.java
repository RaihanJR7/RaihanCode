package com;

import org.testng.annotations.Test;

public class ParallelTest {

	@Test
	public void test1() {
		
	}
	
	
	@Test
	public void test2() {
		
	}
}
