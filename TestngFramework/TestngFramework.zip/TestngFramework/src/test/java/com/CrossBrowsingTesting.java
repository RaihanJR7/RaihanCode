package com;

import org.testng.annotations.Parameters;

public class CrossBrowsingTesting extends BaseTest{
	
	

}
